


from typing import Dict, Text
from requests.models import Response
import requests


class Thingiverse(object):
    def __init__(self):
        self.base_url = "https://api.thingiverse.com"

    def search(self, term: Text) -> Response:
        path = f"/search/{term}/"
        url = self.base_url + path
        res = requests.get(url)
        print(res)
        return res
